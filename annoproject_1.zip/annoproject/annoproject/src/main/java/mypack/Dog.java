package mypack;

import org.springframework.stereotype.Component;

@Component
public class Dog {
    public void behave(){
        System.out.println("CUTE");

    }

}
