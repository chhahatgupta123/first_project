package com.anno.annoproject;

import org.springframework.stereotype.Component;


public class Emp {

    public void whatsyourname(){
        System.out.println("CHAHAT GUPTA");
    }
}
