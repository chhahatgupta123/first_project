package com.anno.annoproject;

import org.springframework.stereotype.Component;


public class Employee {
    public void datatfetch(){
        System.out.println("data is fetching");
    }
}
