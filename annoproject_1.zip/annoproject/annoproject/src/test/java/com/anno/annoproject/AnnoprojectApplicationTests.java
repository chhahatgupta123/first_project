package com.anno.annoproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnnoprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
